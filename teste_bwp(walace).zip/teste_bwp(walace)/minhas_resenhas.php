<?php
include 'cabecalho.php';

?>

<body>

	<div class="menu_esquerda">
	
	<div class="em_volta_da_imagen">

	<div class="redonda">
	<img class="ui medium circular image" src="imagens/usuarioCadastro.png">
	</div>

	</div>
	
<div class="menuzinho">
	<div class="ui inverted vertical menu">
  <a class="item">
    Home
  </a>
  <a class="item">
    Messages
  </a>
  <a class="item active">
    Friends
  </a>
  <a class="item active">
    Minhas Resenhas
  </a>
</div>
</div>
</div>

<div class="opaa">
	




<div class="div_minhas_resenhas1">
	
	<div>
		<img class="imagem_minhas_resenhas" src="imagens/pessoa.png">
	</div>

	<h2 class="fifa_minhas_resenhas">Fifa</h2>

	<button class="excluir19" type="submit" > EXCLUIR</button>   
	<button class="editar" type="submit" > EDITAR</button>
	<button class="visualizar19" type="submit" > VISUALIZAR</button>

</div>


<div class="div_minhas_resenhas2">
	
	<div>
		<img class="imagem_minhas_resenhas" src="imagens/pessoa.png">
	</div>

	<h2 class="fifa_minhas_resenhas">UFC</h2>

	<button class="excluir19" type="submit" > EXCLUIR</button>   
	<button class="editar" type="submit" > EDITAR</button>
	<button class="visualizar19" type="submit" > VISUALIZAR</button>


</div>



</div>

	
	
</body>
</html>