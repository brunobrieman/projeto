<?php

include 'cabecalho.php';
include 'funcoes.php';

$codigo = $_GET['cod'];

$resenha = buscaresenha($codigo);

echo '
<br>



  
<div class="container">

  <!-- Full-width images with number text -->
  <div class="mySlides">
    
       <img src="imagens/'.$resenha['foto1'].'" style="width:100%">
  </div>

  <div class="mySlides">
    
       <img src="imagens/'.$resenha['foto2'].'" style="width:100%">
  </div>

  <div class="mySlides">
    
      <img src="imagens/'.$resenha['foto3'].'" style="width:100%">
  </div>



  <!-- Next and previous buttons -->
  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)">&#10095;</a>

 

  
</div>
<script type="text/javascript">
  var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}
</script>


<iframe  class="sticky"allow="autoplay; encrypted-media" allowfullscreen="" frameborder="0" height="300" src="'.$resenha['video'].'" width="100"  style="margin-top: 6%;" 
  ></iframe>
<div class="texto">
  
  "'.$resenha['Resenha'].'"

	
    


</div>
</div>
</div>
<div class="butao_resenha">
<button class="buttonDetalha"><span> Jogar </span></button>

</div>
</body>
 ';
?>
<style type="text/css">
	
.Comentarios_resenhas{
	margin-left:34%;
	margin-top: 3%; 
}	

</style>


<div style="clear: both;"></div>
<h4 class="ui horizontal divider header">
  <i class="tags icon"></i>
  Comentarios
</h4>

<div class="Comentarios_resenhas">
<div class="ui comments">
  <div class="comment">
    <a class="avatar">
      <img src="imagens/img_avatar.png">
    </a>
    <div class="content">
      <a class="author">Walace</a>
      <div class="metadata">
        <span class="date">Today at 5:42PM</span>
      </div>
      <div class="text">
        How artistic!
      </div>
      <div class="actions">
        <a class="reply">responder</a>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar_usuario.png">
    </a>
    <div class="content">
      <a class="author">Bruno</a>
      <div class="metadata">
        <span class="date">Yesterday at 12:30AM</span>
      </div>
      <div class="text">
        <p>This has been very useful for my research. Thanks as well!</p>
      </div>
      <div class="actions">
        <a class="reply">responder</a>
      </div>
    </div>
    <div class="comments">
      <div class="comment">
        <a class="avatar">
          <img src="imagens/img_avatar.png">
        </a>
        <div class="content">
          <a class="author">Walace</a>
          <div class="metadata">
            <span class="date">Just now</span>
          </div>
          <div class="text">
            Elliot you are always so right :)
          </div>
          <div class="actions">
            <a class="reply">responder</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="comment">
    <a class="avatar">
      <img src="imagens/avatar_feminino.png">
    </a>
    <div class="content">
      <a class="author">Luiza</a>
      <div class="metadata">
        <span class="date">5 days ago</span>
      </div>
      <div class="text">
        Dude, this is awesome. Thanks so much
      </div>
      <div class="actions">
        <a class="reply">responder</a>
      </div>
    </div>
  </div>
  <form class="ui reply form">
    <div class="field">
      <textarea></textarea>
    </div>
    <div class="ui blue labeled submit icon button">
      <i class="icon edit"></i> Enviar</div>
  </form>
</div>

</div>