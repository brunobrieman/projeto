
	

<?php
 include 'cabecalho.php';
 include 'funcoes.php';
?>


	 
	<div class=page>

   
     
       <br>
       <br>
        
         <h1 class="animated fadeInLeftBig tituloIndex"> BWP Resenhas Esportivas</h1>
               	<br>
               	<br>
               	<h1 class="animated fadeInRightBig subtituloIndex">Resenhas esportivas da melhor qualidade</h1>
               <h1 class="animated fadeInLeftBig subtitulo2Index">entre para uma melhor experiencia</h1>
             	<br>
              <?php include 'parte.html'; ?>
                <button class="animated fadeInUp" onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Entrar</button>
                <link href="css/bootstrap.min.css" rel="stylesheet">
               
               	
	
               	


     
     	<section class="animated shake colunaSeta">
     	<a href="#tituloNew"><img class="seta" src="imagens/seta.jpg"></a>
     	 
     	</section>
     	


    
   </div>

               
      
<?php

 $lista=listaResenhas();
 $cont = 0;
 
  foreach ($lista as $dados) {
    $cont++;
    if ($cont>3) {
        break;
    }else{

   



echo '

  
<div class="responsive">
  <div class="gallery">
     <a href="detalha_resenha.php?cod='.$dados["cod_jogo"].'">
      <img src="imagens/'.$dados['foto'].'" alt="Trolltunga Norway" width="300" height="200">
       
    </a>
    <div class="desc">'.$dados['Nome'].'</div>
  </div>
</div>
';

}
}
?>
	


</body>
</html>

